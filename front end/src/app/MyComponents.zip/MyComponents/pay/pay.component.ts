import { Component } from '@angular/core';

@Component({
  selector: 'app-pay',
  templateUrl: './pay.component.html',
  styleUrls: ['./pay.component.css']
})
export class PayComponent {
  payTo: string = 'username';
  recipient: string = '';
  amount: number | null = null;
  note: string = '';
  payVia: string = 'Username';
  convertedCurrencies: { name: string, amount: number }[] = []; // Declare convertedCurrencies property

  updatePayVia() {
    switch (this.payTo) {
      case 'username':
        this.payVia = 'Username';
        break;
      case 'mobile':
        this.payVia = 'Mobile Number';
        break;
      case 'email':
        this.payVia = 'Email';
        break;
      default:
        this.payVia = 'Username';
    }
  }

  convertAmount() {
    // Perform currency conversion calculations here
    // For demonstration, let's assume a fixed conversion rate for major currencies
    const conversionRates: Record<string, number> = {
      'USD': 1,
      'EUR': 0.85,
      'GBP': 0.73,
      'JPY': 110.47,
      'CAD': 1.26
    };
  
    this.convertedCurrencies = [];
  
    if (this.amount !== null) {
      Object.keys(conversionRates).forEach((currency: keyof typeof conversionRates) => {
        this.convertedCurrencies.push({
          name: currency,
          amount: +(this.amount! * conversionRates[currency]).toFixed(2)
        });
      });
    }
  }
  

  pay() {
    // Perform payment processing logic here
    console.log('Paying...');
    console.log('Pay To:', this.payTo);
    console.log('Recipient:', this.recipient);
    console.log('Amount:', this.amount);
    console.log('Note:', this.note);
  }
}
