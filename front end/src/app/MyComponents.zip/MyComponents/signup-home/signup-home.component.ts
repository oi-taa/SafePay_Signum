import { Component } from '@angular/core';

@Component({
  selector: 'app-signup-home',
  templateUrl: './signup-home.component.html',
  styleUrl: './signup-home.component.css'
})
export class SignupHomeComponent {

}
