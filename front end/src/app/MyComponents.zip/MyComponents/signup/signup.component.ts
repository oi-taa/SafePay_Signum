import { Component, OnInit } from '@angular/core'; // Import OnInit
import { SignupService } from '../../services/signup.service';
import { Router } from '@angular/router';
import { SignUp } from '../../datatype';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'] // Corrected styleUrls
})
export class SignupComponent implements OnInit { // Implement OnInit

  constructor(private signup: SignupService, private router: Router) { }
  showLogin =false;
  ngOnInit() {

  }

  signUp(data: SignUp ): void {
    this.signup.userSignUp(data).subscribe((result)=>{
      if(result){
        this.router.navigate(['signup-home'])
      }
    });
    }

}
